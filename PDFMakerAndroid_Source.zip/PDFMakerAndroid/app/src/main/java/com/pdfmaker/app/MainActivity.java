package com.pdfmaker.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Gravity;
import android.graphics.Color;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

public class MainActivity extends Activity {
    private WebView webView;
    private AdView adView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(17,17,22));
        getWindow().setNavigationBarColor(Color.BLACK);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(17,17,22));
        TextView title = new TextView(this);
        title.setText("📄  PDF MAKER");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(18, 12, 18, 12);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(54)));
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("https://pdf-maker.higgsfield.app");
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1f));
        adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);
        // Official Google test banner ID. Replace with your own Ad Unit ID for release.
        adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
        root.addView(adView, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        MobileAds.initialize(this, status -> {});
        adView.loadAd(new AdRequest.Builder().build());
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onPause() { if (adView != null) adView.pause(); if (webView != null) webView.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if (adView != null) adView.resume(); if (webView != null) webView.onResume(); }
    @Override protected void onDestroy() { if (adView != null) adView.destroy(); if (webView != null) webView.destroy(); super.onDestroy(); }
}
