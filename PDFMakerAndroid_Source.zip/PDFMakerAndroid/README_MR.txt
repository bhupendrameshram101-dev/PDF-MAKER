PDF MAKER — Android project source

ही ZIP Android Studio project source आहे; तयार APK नाही.

- अॅप https://pdf-maker.higgsfield.app वेबसाइट उघडतो.
- AdMob साठी Google चे sample TEST App ID आणि TEST banner ad unit वापरले आहेत. यावरून कमाई होत नाही.
- स्वतःचा AdMob App ID AndroidManifest.xml मध्ये आणि Ad Unit ID MainActivity.java मध्ये टाकावा.
- AdMob च्या नियमांनुसार setup/review पूर्ण होईपर्यंत live ads वापरू नका.
- APK तयार करण्यासाठी संगणकावर Android Studio उघडा, हा folder import करा, Gradle Sync करा, नंतर Build > Build Bundle(s) / APK(s) > Build APK(s) निवडा.
- APK साधारण app/build/outputs/apk/debug/app-debug.apk येथे तयार होतो.
- या वातावरणात Android SDK/Gradle उपलब्ध नसल्याने इथे APK compile केलेला नाही.
- हा Android app आहे; iPhone साठी स्वतंत्र iOS build आवश्यक आहे.
